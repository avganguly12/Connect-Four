=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=
CIS 120 Game Project README
PennKey: _______
=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=

===================
=: Core Concepts :=
===================

- List the four core concepts, the features they implement, and why each feature
  is an appropriate use of the concept. Incorporate the feedback you got after
  submitting your proposal.

  1. 2-D Arrays: The most common type of connect-four game board is 7 columns and six rows.
  I represented the board by using a 2-D array of integers. 0 represented an empty spot,
   1 represented Red, and 2 represented Yellow. To start the game,
   every spot is 0 and changes as the spots fill as the game progresses.
   When there is a case with four of a kind adjacently in a column or four
    of a kind arranged horizontally in a row (as per the rules of the game),
    the method checkForGameWinner() identifies this case and ends the game. There
    are 2-d array traversals to actually check for a winner or tie case within 
    this method.

  2. Collection: There is an undo feature that takes off the last element of 
  an arraylist containing all the moves and removes the piece from the board 
  that corresponds to that move. I used an arraylist since it's easy to remove
  the last element and it efficiently stores all the moves that I needed 
  throughout my game.

  3. I the state using I/O, so when the game is paused
   the board and moves will be saved as a text file that can be read again
   to get back to the game at the same spot that it was paused.
   Thus, the game has both a reader and a writer that are activated when their
   corresponding buttons are pressed. 

  4. Testable Component: I test that a winner is correctly found, that moves
  function properly in the board, that I can't add moves to a filled column,
  and the cases where a winner could occur are detected and identified, and 
  that the various methods in my move class are functional as well. This does 
  not interfere with the GUI in any way.


=========================
=: Your Implementation :=
=========================

- Provide an overview of each of the classes in your code, and what their
  function is in the overall game.

	I have three classes: the move class, the board class, and the name class. The move
	class contains three fields: the row, the column, and the player's number. I make sure
	that the player can only have a number between 0 and 2 inclusive. 
	
	The board class applies the move class to a 2-d array, handling events like making a move
	checking for a winner, preventing the user from adding to a column that's already full,
	and more. 
	
	The Game class applies the board class and constructs the GUI. It takes in user input
	through key presses and applies the proper move based on whether the move is valid or not.
	Moreover, it also provides an instructions panel and game end panel to guide the user.
	Additionally, the Game class contains 3 buttons (undo, save, and load), which can 
	undo a move, save the state of the game to a text file, and read from that text file
	to load a new game.  


- Were there any significant stumbling blocks while you were implementing your
  game (related to your design, or otherwise)?
	I struggled with correctly zipping my file since I trying to import a package
	instead of import org.junit.*; which lead to my code failing to compile and
	my test cases to not work. 


- Evaluate your design. Is there a good separation of functionality? How well is
  private state encapsulated? What would you refactor, if given the chance?
  
  I like the fact that my game uses very few classes and is relatively efficient. Private
  state is also well encapsulated since if you try to get the 2-d array representing
  the board, you only get a copy and not the actual state of the board itself. This
  holds for other areas of my code as well throughout my board class.
  
  There are some areas like the actual piece placement in the GUI I could potentially
  refactor if given the chance. 



========================
=: External Resources :=
========================

- Cite any external resources (libraries, images, tutorials, etc.) that you may
  have used while implementing your game.
  
  All the material relating to the four core concepts (2-d arrays, collections, 
  JUnit testing, and I/O) were things I implemented myself. However, I did look at some
  tutorials and examples for coming up with how I would construct my GUI. 
  
  I got my images and some guidance from the following links: 
 https://www.youtube.com/watch?v=SxstLdf9LkE
 https://github.com/Iptamenos/Connect-4
 https://www.youtube.com/watch?v=B5H_t0A_C14
 
The code for making my ImageIcons came from the java documentation:
https://docs.oracle.com/javase/tutorial/uiswing/components/icon.html
 
  
  
  
  
